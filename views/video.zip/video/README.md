## 安装

```bash
npm i @k9/video -S
```

## 引入
```
import Video from '@k9/video'

components: {
    Video
}
```

## Props
|参数|说明|类型|可选值|默认值|
|---|---|---|---|---|

## Events

|事件名|说明|回调参数|
|---|---|---|

## 其他
有问题可知音楼联系：晨曦老师
